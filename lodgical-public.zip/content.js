(function(){function e(e){return(e??``).replace(/\s+/g,` `).trim().slice(0,500)}var t,n=``;document.addEventListener(`selectionchange`,()=>{window.clearTimeout(t),t=window.setTimeout(()=>{let t=e(document.getSelection()?.toString());if(t===n)return;n=t;let r={channel:`lodgical-selection`,text:t,url:location.href};try{chrome.runtime.sendMessage(r).catch(()=>{})}catch{}},300)});function r(e){return e.includes(`property24`)?`property24`:e.includes(`privateproperty`)?`private_property`:`manual`}function i(e){if(!e)return!1;let t;try{t=new URL(e)}catch{return!1}let n=t.pathname.split(`/`).filter(Boolean),i=n[n.length-1]??``;switch(r(t.hostname)){case`property24`:return n.length>=6&&/^\d{6,}$/.test(i);case`private_property`:return/^(?:RR|T)\d{4,}$/i.test(i);default:return!1}}var a=`lodgical:extensionSettings`,o=`lodgical:siteHintsSeen`,s={toolbarClick:`preview`,openPanelOnSave:!0,showBadge:!0,siteHints:!0};function c(e){let t=typeof e==`object`&&e?e:{};return{toolbarClick:t.toolbarClick===`immediate`?`immediate`:`preview`,openPanelOnSave:typeof t.openPanelOnSave==`boolean`?t.openPanelOnSave:s.openPanelOnSave,showBadge:typeof t.showBadge==`boolean`?t.showBadge:s.showBadge,siteHints:typeof t.siteHints==`boolean`?t.siteHints:s.siteHints}}function l(e){return Array.isArray(e)?e.filter(e=>typeof e==`string`):[]}function u(e,t,n){return e.siteHints&&n!==null&&!t.includes(n)}var d={property24:`Property24`,private_property:`PrivateProperty`};async function f(){if(!i(location.href))return;let e=r(location.hostname),t=await chrome.storage.local.get([a,o]),n=l(t[o]);u(c(t[`lodgical:extensionSettings`]),n,e===`manual`?null:e)&&(await chrome.storage.local.set({[o]:[...n,e]}),p(d[e]??`this site`))}function p(e){let t=document.createElement(`div`),n=t.attachShadow({mode:`closed`});n.innerHTML=`
    <style>
      .hint { position: fixed; top: 16px; right: 16px; z-index: 2147483647; max-width: 320px; box-sizing: border-box;
        padding: 14px 16px; border-radius: 12px; background: #fff; color: #292524; border: 1px solid #e7e5e4;
        box-shadow: 0 10px 30px rgba(0,0,0,.18); font: 14px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif; }
      .title { margin: 0 0 4px; font-weight: 600; color: #3D6139; }
      p { margin: 0; }
      .badge { display: inline-block; min-width: 16px; padding: 0 3px; border-radius: 4px; background: #57534E;
        color: #fff; font-size: 12px; font-weight: 600; text-align: center; }
      button { margin-top: 10px; padding: 6px 14px; border: 0; border-radius: 8px; background: #3D6139; color: #fff;
        font: inherit; font-weight: 500; cursor: pointer; }
    </style>
    <div class="hint" role="status">
      <p class="title">Lodgical can save listings from ${e}</p>
      <p>Click the Lodgical button (the green square with a roof) in your browser's toolbar. It shows <span class="badge">+</span> on a
        listing you haven't saved yet. Not in the toolbar? Open the browser's Extensions menu (the puzzle-piece button)
        and pin Lodgical.</p>
      <button type="button">Got it</button>
    </div>`,n.querySelector(`button`).addEventListener(`click`,()=>t.remove()),document.documentElement.append(t)}try{f().catch(()=>{})}catch{}})();